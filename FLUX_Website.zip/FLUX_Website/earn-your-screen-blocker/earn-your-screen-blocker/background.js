const DEFAULT=[{"d":"x.com","learn":false},{"d":"twitter.com","learn":false},{"d":"discord.com","learn":false},{"d":"instagram.com","learn":false},{"d":"tiktok.com","learn":false},{"d":"reddit.com","learn":false},{"d":"snapchat.com","learn":false},{"d":"twitch.tv","learn":false},{"d":"facebook.com","learn":false},{"d":"youtube.com","learn":true}];
async function apply(){
 const o=await chrome.storage.local.get("eys");const s=o.eys||{};
 const block=s.block||DEFAULT,now=Date.now();
 const open=now<(s.unlockUntil||0),learn=now<(s.learnUntil||0);
 const active=open?[]:block.filter(b=>!(b.learn&&learn)).map(b=>b.d);
 const old=await chrome.declarativeNetRequest.getDynamicRules();
 await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:old.map(r=>r.id),addRules:active.map((d,i)=>({id:i+1,priority:1,action:{type:"redirect",redirect:{extensionPath:"/lock.html"}},condition:{requestDomains:[d],resourceTypes:["main_frame","sub_frame"]}}))});
}
chrome.runtime.onMessage.addListener(m=>{
 const s=m&&m.state;if(!s||!Array.isArray(s.block))return;
 chrome.storage.local.set({eys:{unlockUntil:+s.unlockUntil||0,learnUntil:+s.learnUntil||0,block:s.block.slice(0,100).map(b=>({d:String(b.d).slice(0,100),learn:!!b.learn}))}});
});
chrome.storage.onChanged.addListener((c,a)=>{if(a==="local"&&c.eys)apply()});
chrome.alarms.create("tick",{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(apply);
chrome.runtime.onInstalled.addListener(apply);chrome.runtime.onStartup.addListener(apply);
