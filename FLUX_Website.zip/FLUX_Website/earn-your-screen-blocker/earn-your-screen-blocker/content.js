const KEY="3a10184659e512d996eac2e4";
window.addEventListener("message",e=>{
 if(e.source!==window||!e.data||e.data.eys!=="state"||e.data.key!==KEY)return;
 chrome.runtime.sendMessage({state:e.data.state},()=>{void chrome.runtime.lastError;window.postMessage({eys:"ack",key:KEY},"*")});
});
