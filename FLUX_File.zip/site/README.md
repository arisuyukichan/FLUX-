# Earn Your Screen: website

Frontend: `public/index.html`. Backend: `server.js` (static files + WebSocket study rooms at `/ws`).

    npm install      # only if node_modules is missing
    npm start        # http://localhost:3000
    npm test         # starts a server and checks rooms, presence, sanitising, path traversal

Deploy on any Node 18+ host (Render, Fly, Railway, a VPS). Use HTTPS so the page upgrades to wss://.
Rooms live in memory: no accounts, no database, nothing is stored. For real accounts or friend lists, add auth and a database in `server.js`.
Limits: 20 people per room, 2 KB messages, 8 messages per second per connection.
