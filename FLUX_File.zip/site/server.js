// Earn Your Screen: static file server + WebSocket study rooms.
// Rooms are in memory only. Nothing is stored. Restarting clears them.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const MAX_PER_ROOM = 20;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  if (req.url === '/healthz') { res.writeHead(200); return res.end('ok'); }
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }   // no path traversal
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, {
      'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff'
    });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 2048 });
const rooms = new Map();   // code -> Map(id -> { ws, s })

const clean = (v, n) => String(v ?? '').replace(/[\u0000-\u001f<>]/g, '').slice(0, n);
const cleanState = s => ({ h: clean(s?.h, 24), t: clean(s?.t, 40), p: !!s?.p, m: Math.min(9999, Math.max(0, Number(s?.m) | 0)) });

function broadcast(code) {
  const room = rooms.get(code);
  if (!room) return;
  const peers = [...room].map(([id, c]) => ({ id, s: c.s }));
  for (const [id, c] of room) {
    if (c.ws.readyState === 1) c.ws.send(JSON.stringify({ t: 'peers', you: id, peers }));
  }
}

function leave(ws) {
  if (!ws.room) return;
  const room = rooms.get(ws.room);
  if (room) { room.delete(ws.id); if (!room.size) rooms.delete(ws.room); else broadcast(ws.room); }
  ws.room = null;
}

wss.on('connection', ws => {
  ws.id = crypto.randomBytes(6).toString('hex');
  ws.room = null;
  ws.hits = 0;
  const reset = setInterval(() => { ws.hits = 0; }, 1000);

  ws.on('message', raw => {
    if (++ws.hits > 8) return;                       // crude rate limit
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'join') {
      const code = clean(m.room, 30).toLowerCase().replace(/[^a-z0-9-]/g, '');
      if (!code) return;
      leave(ws);
      const room = rooms.get(code) || new Map();
      if (room.size >= MAX_PER_ROOM) { ws.send(JSON.stringify({ t: 'full' })); return; }
      room.set(ws.id, { ws, s: cleanState({}) });
      rooms.set(code, room);
      ws.room = code;
      broadcast(code);
    } else if (m.t === 'presence' && ws.room) {
      const c = rooms.get(ws.room)?.get(ws.id);
      if (c) { c.s = cleanState(m.s); broadcast(ws.room); }
    }
  });
  ws.on('close', () => { clearInterval(reset); leave(ws); });
});

if (require.main === module) server.listen(PORT, () => console.log('Earn Your Screen on http://localhost:' + PORT));
module.exports = { server, wss };
