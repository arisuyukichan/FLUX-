// Starts the server on a random port and checks static serving, rooms, presence and limits.
const assert = require('assert');
const WebSocket = require('ws');
const { server } = require('./server');

const open = (url) => new Promise(r => { const w = new WebSocket(url); w.on('open', () => r(w)); });
const next = (w, pred) => new Promise(r => w.on('message', d => { const m = JSON.parse(d); if (pred(m)) r(m); }));

server.listen(0, async () => {
  const port = server.address().port, base = 'http://localhost:' + port;
  try {
    assert.strictEqual((await fetch(base + '/healthz')).status, 200);
    const page = await (await fetch(base + '/')).text();
    assert.ok(page.includes('Earn your'));
    assert.notStrictEqual((await fetch(base + '/..%2fserver.js')).status, 200, 'path traversal must not serve files');

    const a = await open('ws://localhost:' + port + '/ws');
    const b = await open('ws://localhost:' + port + '/ws');
    a.send(JSON.stringify({ t: 'join', room: 'Study-1' }));
    b.send(JSON.stringify({ t: 'join', room: 'study-1' }));
    const both = await next(a, m => m.t === 'peers' && m.peers.length === 2);
    assert.strictEqual(both.peers.length, 2);

    b.send(JSON.stringify({ t: 'presence', s: { h: 'Fox-12<b>', t: 'Drawing', p: true, m: 5 } }));
    const upd = await next(a, m => m.t === 'peers' && m.peers.some(p => p.s.p === true));
    const other = upd.peers.find(p => p.id !== upd.you);
    assert.strictEqual(other.s.h, 'Fox-12b', 'markup characters must be stripped');
    assert.strictEqual(other.s.m, 5);

    b.close();
    const left = await next(a, m => m.t === 'peers' && m.peers.length === 1);
    assert.strictEqual(left.peers.length, 1);
    a.close();
    console.log('all backend checks passed');
    process.exit(0);
  } catch (e) { console.error('FAIL', e.message); process.exit(1); }
});
